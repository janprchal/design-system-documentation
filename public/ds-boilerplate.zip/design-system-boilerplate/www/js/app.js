'use strict';

if (!Element.prototype.matches) {
  Element.prototype.matches = Element.prototype.msMatchesSelector || 
                              Element.prototype.webkitMatchesSelector;
}

if (!Element.prototype.closest) {
  Element.prototype.closest = function(s) {
    var el = this;

    do {
      if (Element.prototype.matches.call(el, s)) return el;
      el = el.parentElement || el.parentNode;
    } while (el !== null && el.nodeType === 1);
    return null;
  };
}

document.addEventListener('DOMContentLoaded', function() {
  const nav = new Nav; // start navigace
  
  var drawerTrigger = document.getElementsByClassName('js_drawerTrigger');
  var drawerClose = document.getElementsByClassName('js_drawerClose');

  // TODO do classy
  function findDrawer(identifier) {
    return document.getElementById(identifier);
  };

  [].forEach.call(drawerTrigger, function(trigger) {
    trigger.addEventListener('click', function(e) {
      var drawer = findDrawer(e.target.dataset.drawer);
      drawer.classList.toggle('is-open');
    })
  });

  [].forEach.call(drawerClose, function(close) {
    close.addEventListener('click', function(e) {
      var drawer = e.target.closest(".c-drawer");
      if(drawer.classList.contains('is-open')) {
        drawer.classList.remove('is-open');
      }
    })
  });
  const dropdowns = new Dropdowns();
  const fileInputs = new FileInputs('.js_file');
  const modals = new Modals();
});

class Dropdowns {
  constructor() {
    this.ACTIVE_CLASS     = 'is-visible';
    this.HIDDEN_CLASS     = 'is-hidden';
    this._activeDropdown  = null;
    this.triggers         = document.querySelectorAll('[data-dropdown-trigger]');
    this.lists            = document.querySelectorAll('[data-dropdown-list]');

    if(!!this.triggers.length) {
      this.triggers.forEach(trigger => {
        trigger.addEventListener('click', e => {
          e.stopPropagation();

          const dropdown = this.findDropdown(trigger);

          this.hideAllDropdowns();
          this.toggleDropdown(dropdown);
        });
      })
    }

    document.addEventListener('click', e => {
      if(!e.target.closest('[data-dropdown-list]')) {
        this.hideAllDropdowns();
      }
    });
  }

  findDropdown(trigger) {
    return trigger.parentNode.querySelectorAll('[data-dropdown-list]')[0];
  }

  showDropdown(dropdown) {
    this._activeDropdown = dropdown;
    dropdown.classList.add(this.ACTIVE_CLASS);
  }

  hideDropdown(dropdown) {
    dropdown.classList.remove(this.ACTIVE_CLASS);
    this._activeDropdown = null;
  }

  toggleDropdown(dropdown) {
    dropdown.classList.toggle(this.ACTIVE_CLASS);
    this.activeDropdown = dropdown;
  }

  hideAllDropdowns() {
    this.lists.forEach(list => {
      list.classList.remove(this.ACTIVE_CLASS);
    })
    this._activeDropdown = null;
  }

  set activeDropdown(dropdown) {
    this._activeDropdown = dropdown;
  }

  get activeDropdown() {
    return this._activeDropdown;
  }
}

class FileInputs {
  constructor(selector) {
    this.inputs = document.querySelectorAll(selector);

    [].forEach.call(this.inputs, input => {
      input.addEventListener('change', event => {
        this.writeFilePath(input, event.target.value);
      })
    });
  }

  writeFilePath(input, filePath) {
    let fileName = this._extractFilename(filePath);
    const label = input.nextElementSibling;
    label.innerHTML = fileName;
  }

  _extractFilename(path) {
    if (path.substr(0, 12) == "C:\\fakepath\\")
      return path.substr(12); // modern browser
    var x;
    x = path.lastIndexOf('/');
    if (x >= 0) // Unix-based path
      return path.substr(x+1);
    x = path.lastIndexOf('\\');
    if (x >= 0) // Windows-based path
      return path.substr(x+1);
    return path; // just the file name
  }
} 

class Modals {
  constructor() {
    this.ACTIVE_CLASS   = 'is-open';
    this.triggers       = document.querySelectorAll('[data-modal-trigger]')
    this.modals         = document.querySelectorAll('[data-modal]');
    this.closes         = document.querySelectorAll('[data-modal-close]');

    if(!!this.triggers.length) {
      this.triggers.forEach(trigger => {
        trigger.addEventListener('click', e => {
          e.stopPropagation();

          const modal = this.findModal(trigger.getAttribute('data-modal-trigger'));

          this.hideAllModals();
          this.showModal(modal);
        })
      })
    }

    if(!!this.closes.length) {
      this.closes.forEach(close => {
        close.addEventListener('click', e => {
          e.stopPropagation();
          
          const modal = e.target.closest('[data-modal]');
          this.hideModal(modal);
        })
      })
    }
  }

  findModal(modalId) {
    return [...this.modals].filter(modal => modal.getAttribute('data-modal') === modalId)[0]
  }

  hideAllModals() {
    this.modals.forEach(modal => this.hideModal(modal));
  }

  showModal(modal) {
    modal.classList.add(this.ACTIVE_CLASS);
    modal.querySelectorAll('[data-modal-dialog]')[0].classList.add(this.ACTIVE_CLASS);
  }

  hideModal(modal) {
    modal.classList.remove(this.ACTIVE_CLASS);
    modal.querySelectorAll('[data-modal-dialog]')[0].classList.remove(this.ACTIVE_CLASS);
  }
}
"use strict";

class Nav {
  constructor() {
    this.trigger          = document.getElementById('js_navTrigger'); //mobile trigger of nav
    this.block            = document.getElementById('js_navBlock'); // navigation block
    this.appHeader        = document.getElementById('js_header'); // apps header isn't used now
    this.itemsWithSubnav  = document.getElementsByClassName('js_subnav');
    this.collapse         = document.querySelectorAll('[data-collapse]')[0];
    
    if(this._getCookie('collapsed') === false) {
      this._setCookie('collapsed', 'uncollapsed', 365);
    }
    
    /**
     * Commented out to prevent from show collapsed state as default
     * since Chrome cant create cookie without localhost
     * TODO try to use localStorage instead of cookie
     */
    // If collapse is el is on screen
    // if(this.collapse) {
    //   if(this._getCookie('collapsed') === 'uncollapsed') {
    //     this.collapse.setAttribute('data-collapse', 'uncollapsed')
    //     document.body.classList.remove('nav-collapsed');
    //   } else {
    //     this.collapse.setAttribute('data-collapse', 'collapsed')
    //     document.body.classList.add('nav-collapsed');
    //   }
    // }

    if(this.trigger) {
      this.trigger.addEventListener('click', () => {
        if(this.block.classList.contains('is-open')) {
          this._closeNavBlock();
        } else {
          this._openNavBlock()
        }
      });
    }

    [].forEach.call(this.itemsWithSubnav, itemWithSubnav => {
      itemWithSubnav.addEventListener('click', event => {
        let item    = event.target.closest('.c-nav__link');
        let subnav  = item.nextElementSibling;

        this.processNavItem(item, subnav);
      })
    });

    // if collapse el is on screen watch for click
    if(this.collapse) {
      this.collapse.addEventListener('click', event => {
        if(this.collapse.getAttribute('data-collapse') === 'collapsed') {
          this.collapse.setAttribute('data-collapse', 'uncollapsed')
          document.body.classList.remove('nav-collapsed');
          document.cookie ='collapsed=uncollapsed; expires=Fri, 31 Dec 2030 23:59:59';
        } else {
          this.collapse.setAttribute('data-collapse', 'collapsed')
          document.body.classList.add('nav-collapsed');
          document.cookie = 'collapsed=collapsed; expires=Fri, 31 Dec 2030 23:59:59';
        }
      });
    }
  }

  // TODO predelat na data-attributes? naznaceno na
  // https://css-tricks.com/using-css-transitions-auto-dimensions/
  processNavItem(item, subnav) {
    if(item.classList.contains('is-active')) {
      item.classList.remove('is-active');
      this._collapseBlock(subnav);
      subnav.classList.remove('is-open');
    } else {
      item.classList.add('is-active');
      this._expandBlock(subnav);
      subnav.classList.add('is-open');
    }
  }

  _openNavBlock() {
    this.trigger.classList.add('is-open');
    this.block.classList.add('is-open');
    this.appHeader.classList.add('nav-open'); // isn't used yet
  }

  _closeNavBlock() {
    this.trigger.classList.remove('is-open');
    this.block.classList.remove('is-open');
    this.appHeader.classList.remove('nav-open'); // isn't used yet
  }

  // TODO vysvetleni na
  // https://css-tricks.com/using-css-transitions-auto-dimensions/
  _collapseBlock(block) {
    const blockHeight = block.scrollHeight;

    // temporarily disable all css transitions
    const blockTransition = block.style.transition;
    block.style.transition = ''; // reset block transition

    requestAnimationFrame(() => {
      block.style.height = blockHeight + 'px';
      block.style.transition = blockTransition; 

      requestAnimationFrame(() => {
        block.style.height = 0 + 'px';
      })
    })
  }

  _expandBlock(block) {
    const sectionHeight = block.scrollHeight;

    block.style.height = sectionHeight + 'px';
    block.addEventListener('transitioned', function(e) {
      // TODO get rid of arguments.callee
      block.removeEventListener('transitionend', arguments.callee);

      block.style.height = null;
    });
  }

  _getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return false;
  }

  _setCookie(cname, value, exdays) {
    console.log("_setCookie called");
    const d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    let expires = `expires=${d.toUTCString()}`;
    document.cookie = `${cname}=${value};${expires};path=/`;
  }
}

class Tabs {
  constructor(tabsBlockId) {
    this.tabsBlock        = document.getElementById(tabsBlockId);
    this.selectedTab      = null;
    this.selectedContent  = null;
    this.tabs             = this.tabsBlock.querySelectorAll('[data-target]');
    this.tabsContents     = this.tabsBlock.querySelectorAll('[data-identifier]');
    this.ACTIVE_CLASS     = 'is-active';
    this.panels           = this.tabsBlock.querySelectorAll('[role="tabpanel"]');
    this.hasTabs          = true;

    this.modeSwitcher();
    this.showFirstTab();

    [].forEach.call(this.tabs, tab => {
      tab.addEventListener('click', event => {
        const tab = event.target;
        const tabContent = this.findTabContent(event.target.getAttribute('data-target'));
        
        this.activateTab(tab, tabContent)
      })
    });

    [].forEach.call(this.panels, panel => {
      panel.addEventListener('click', event => {
        if(!this.tabsActive) {
          const tabContent = event.target;
          const tab = this.findTab(event.target.getAttribute('data-identifier'));
          
          if(!tabContent.closest('.c-tabs__tab').classList.contains('is-active')) {
            this.activateTab(tab, tabContent);
          }
        }
      })
    });

    const resizeObserver = new ResizeObserver(entries => {
      for(const entry of entries) {
        this.modeSwitcher(entry.contentRect.width)
      }
    });

    resizeObserver.observe(this.tabsBlock.querySelector('.c-tabs__buttons'));
  }

  showFirstTab() {
    const tab = [...this.tabs].shift();
    const tabContent = [...this.tabsContents].shift();

    this.activateTab(tab, tabContent);
  }

  findTab(tabIdentifier) {
    return [...this.tabs].find(tab => tab.getAttribute('data-target') === tabIdentifier);
  }

  findTabContent(tabContentCoordinates) {
    return [...this.tabsContents].find( tabContent => tabContent.getAttribute('data-identifier') === tabContentCoordinates );
  }

  activateTab(tab, content) {
    if(this.activeTab) {
      this.deactivateTab();
    }

    tab.classList.add(this.ACTIVE_CLASS);
    content.classList.add(this.ACTIVE_CLASS);

    this.activeTab = tab;
    this.activeContent = content;
  }

  deactivateTab() {
    const tab = this.activeTab;
    const content = this.activeContent;

    tab.classList.remove(this.ACTIVE_CLASS);
    content.classList.remove(this.ACTIVE_CLASS);

    this.activeTab = null;
    this.activeContent = null;
  }

  // Switch between Tabs and Accordion mode based on width of
  // container and sum of tabs buttons widths
  modeSwitcher(containerWidth) {
    const tabs = this.tabsBlock.querySelectorAll('.c-tabs__button');
    const container = this.tabsBlock;
    let totalW = 0;

    for (const tab of tabs) {
      totalW += tab.offsetWidth;
    }

    if(totalW >= containerWidth) {
      container.classList.remove('has-tabs');
    } else {
      container.classList.add('has-tabs');
    }

    this.tabsActive = container.classList.contains('has-tabs');
  }

  get tabsActive() {
    return this.hasTabs;
  }

  set tabsActive(isActive) {
    this.hasTabs = isActive; 
  }

  get activeTab() {
    return this.selectedTab;
  }

  set activeTab(tab) {
    this.selectedTab = tab;
  }

  get activeContent() {
    return this.selectedContent;
  }

  set activeContent(activeContent) {
    this.selectedContent = activeContent;
  }
}
